

getwd()
setwd("C:\\Users\\PC\\Desktop\\3rd Semester\\PS\\Lab Sheet\\Lab 07")
getwd()


# 01)

punif(25, min = 0, max = 40, lower.tail = TRUE) - punif(10, min = 0, max = 40, lower.tail = TRUE)



# 02)

pexp(2, rate = 1/3, lower.tail = TRUE)



# 03)

## a)

pnorm(130, mean = 100, sd = 15, lower.tail = FALSE)


## b)

qnorm(0.95, mean = 100, sd = 15, lower.tail = TRUE)



